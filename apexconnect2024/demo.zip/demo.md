# Installation der apexconnect-demo

## Voraussetzung
- Oracle 23c
- APEX_23.2

## Ausführen des SQL-Skripts
- demo-schema.sql

## Imporieten der Applikation in APEX
- demo-apex.sql